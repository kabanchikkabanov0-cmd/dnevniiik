package com.grofik.dnevnik;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

final class Notifications {
    static final String MESSAGES = "diary_messages";
    static final String CALLS = "diary_incoming_calls";
    static final String ACTIVE = "diary_active_call";
    
    static void channels(Context c) {
        NotificationManager m = c.getSystemService(NotificationManager.class);
        
        NotificationChannel messages = new NotificationChannel(MESSAGES, "Сообщения", NotificationManager.IMPORTANCE_HIGH);
        messages.setDescription("Уведомления чата");
        messages.setLockscreenVisibility(NotificationCompat.VISIBILITY_PRIVATE);
        messages.enableVibration(true);
        messages.setShowBadge(true);
        
        NotificationChannel calls = new NotificationChannel(CALLS, "Входящие звонки", NotificationManager.IMPORTANCE_HIGH);
        calls.setDescription("Уведомления о входящих звонках");
        calls.setLockscreenVisibility(NotificationCompat.VISIBILITY_PRIVATE);
        calls.enableVibration(true);
        calls.setShowBadge(true);
        calls.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build());
        
        NotificationChannel ongoing = new NotificationChannel(ACTIVE, "Активный разговор", NotificationManager.IMPORTANCE_LOW);
        ongoing.setDescription("Текущий голосовой разговор");
        ongoing.setLockscreenVisibility(NotificationCompat.VISIBILITY_PRIVATE);
        
        m.createNotificationChannel(messages);
        m.createNotificationChannel(calls);
        m.createNotificationChannel(ongoing);
    }
    
    static PendingIntent open(Context c, String peer) {
        Intent i = new Intent(c, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (peer != null) i.putExtra("peer", peer);
        return PendingIntent.getActivity(c, peer == null ? 0 : peer.hashCode(), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    
    static Notification ongoing(Context c, String peer) {
        return new NotificationCompat.Builder(c, ACTIVE)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Звонок в дневнике")
            .setContentText(peer == null || peer.isEmpty() ? "Нажми, чтобы вернуться" : peer)
            .setContentIntent(open(c, peer))
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .build();
    }
    
    static void show(Context c, String kind, String title, String text, String peer, String eventId) {
        channels(c);
        
        if (Build.VERSION.SDK_INT >= 33 && 
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            return;
        
        boolean call = "call".equals(kind);
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, call ? CALLS : MESSAGES)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(limit(title, 100))
            .setContentText(limit(text, 500))
            .setStyle(new NotificationCompat.BigTextStyle().bigText(limit(text, 500)))
            .setContentIntent(open(c, peer))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(call ? NotificationCompat.CATEGORY_CALL : NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setOnlyAlertOnce(true);
            
        if (call) {
            b.setTimeoutAfter(45000)
             .addAction(0, "Открыть звонок", open(c, peer))
             .setFullScreenIntent(open(c, peer), true);
        }
        
        int id = (kind + ":" + (eventId == null ? peer : eventId)).hashCode() & 0x7fffffff;
        if (id == 9001) id++;
        
        c.getSystemService(NotificationManager.class).notify(id, b.build());
    }
    
    private static String limit(String s, int n) {
        if (s == null) return "";
        return s.length() > n ? s.substring(0, n) : s;
    }
}

