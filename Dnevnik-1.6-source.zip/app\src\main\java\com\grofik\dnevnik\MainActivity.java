﻿package com.grofik.dnevnik;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private PermissionRequest pendingMic;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingPeer;
    private boolean resumed = false;
    private static final int PERMS_REQUEST_CODE = 100;
    private boolean permissionsRequested = false;
    
    @Override 
    public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(0xfff5f5f7);
        getWindow().setNavigationBarColor(0xfff5f5f7);
        
        Notifications.channels(this);
        web = new WebView(this);
        setContentView(web);
        
        web.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), 
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });
        
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        
        web.addJavascriptInterface(new Bridge(), "DiaryAndroid");
        
        web.setWebViewClient(new WebViewClient() {
            @Override 
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String url = r.getUrl().toString();
                if (url.equals("file:///android_asset/index.html") || url.startsWith("file:///android_asset/index.html#")) 
                    return false;
                if ("https".equals(r.getUrl().getScheme()))
                    try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception ignored) {}
                return true;
            }
            @Override 
            public void onPageFinished(WebView v, String url) {
                openPendingPeer();
                if (!permissionsRequested) {
                    permissionsRequested = true;
                    requestAllPermissions();
                }
            }
        });
        
        web.setWebChromeClient(new WebChromeClient() {
            @Override 
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean microphone = false;
                    for (String r : request.getResources())
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) microphone = true;
                    if (!microphone || !request.getOrigin().toString().startsWith("file://")) {
                        request.deny();
                        return;
                    }
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                        request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    else {
                        if (pendingMic != null) pendingMic.deny();
                        pendingMic = request;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 71);
                    }
                });
            }
            @Override 
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingMic == request) pendingMic = null;
            }
            @Override 
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(Intent.createChooser(i, "Выбрать фото"), 72);
                } catch (Exception e) {
                    cb.onReceiveValue(null);
                    fileCallback = null;
                }
                return true;
            }
        });
        
        readIntent(getIntent());
        web.loadUrl("file:///android_asset/index.html");
        
        FirebaseMessaging.getInstance().getToken()
            .addOnSuccessListener(token -> 
                getSharedPreferences("push", MODE_PRIVATE).edit().putString("token", token).apply());
        
        FirebaseMessaging.getInstance().subscribeToTopic("all_users");
    }
    
    private void requestAllPermissions() {
        SharedPreferences prefs = getSharedPreferences("perms", MODE_PRIVATE);
        if (prefs.getBoolean("asked", false)) {
            return;
        }
        
        java.util.List<String> needed = new java.util.ArrayList<>();
        
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO);
        }
        
        if (Build.VERSION.SDK_INT >= 33 && 
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.READ_MEDIA_IMAGES);
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            }
        }
        
        if (!needed.isEmpty()) {
            new AlertDialog.Builder(this)
                .setTitle("Разрешения для работы")
                .setMessage("Для полноценной работы дневника нужны доступы:\n\n" +
                    "Микрофон — для голосовых звонков\n" +
                    "Уведомления — чтобы видеть сообщения и звонки\n" +
                    "Фото и видео — чтобы прикреплять фото к ДЗ\n\n" +
                    "Нажмите Разрешить и подтвердите в системных окнах.")
                .setPositiveButton("Разрешить", (dialog, which) -> {
                    ActivityCompat.requestPermissions(this, 
                        needed.toArray(new String[0]), PERMS_REQUEST_CODE);
                })
                .setNegativeButton("Позже", (dialog, which) -> {
                    prefs.edit().putBoolean("asked", true).apply();
                })
                .setCancelable(false)
                .show();
        } else {
            prefs.edit().putBoolean("asked", true).apply();
        }
    }
    
    @Override 
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == 71 && pendingMic != null) {
            PermissionRequest p = pendingMic;
            pendingMic = null;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                p.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            else
                p.deny();
            return;
        }
        
        if (requestCode == PERMS_REQUEST_CODE) {
            getSharedPreferences("perms", MODE_PRIVATE).edit().putBoolean("asked", true).apply();
            
            boolean micGranted = false;
            for (int i = 0; i < permissions.length; i++) {
                if (Manifest.permission.RECORD_AUDIO.equals(permissions[i]) && 
                    grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    micGranted = true;
                    break;
                }
            }
            
            if (micGranted && pendingMic != null) {
                PermissionRequest p = pendingMic;
                pendingMic = null;
                p.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            }
        }
    }
    
    @Override 
    protected void onResume() {
        super.onResume();
        resumed = true;
    }
    
    @Override 
    protected void onPause() {
        resumed = false;
        super.onPause();
    }
    
    @Override 
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        readIntent(i);
        openPendingPeer();
    }
    
    private void readIntent(Intent i) {
        if (i != null) {
            pendingPeer = i.getStringExtra("peer");
            if (pendingPeer != null && pendingPeer.length() > 100) pendingPeer = null;
        }
    }
    
    private void openPendingPeer() {
        if (web == null || pendingPeer == null) return;
        String p = JSONObject.quote(pendingPeer);
        pendingPeer = null;
        web.evaluateJavascript("window.DiaryNativeUI?.openPeer(" + p + ")", null);
    }
    
    @Override 
    protected void onActivityResult(int r, int result, Intent data) {
        super.onActivityResult(r, result, data);
        if (r == 72 && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileCallback = null;
        }
    }
    
    @Override 
    public void onBackPressed() {
        web.evaluateJavascript("(function(){if(window.DiaryCalls?.active()&&!document.getElementById(\"voice-panel\").hidden){window.DiaryCalls.minimize();return \"call\";}return \"back\";})()", 
            v -> { if (!"\"call\"".equals(v)) moveTaskToBack(true); });
    }
    
    @Override 
    protected void onDestroy() {
        stopService(new Intent(this, CallService.class));
        if (pendingMic != null) pendingMic.deny();
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        if (web != null) {
            web.removeJavascriptInterface("DiaryAndroid");
            web.destroy();
        }
        super.onDestroy();
    }
    
    private void requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && 
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 73);
    }
    
    private void showToken() {
        FirebaseMessaging.getInstance().getToken()
            .addOnSuccessListener(token -> {
                getSharedPreferences("push", MODE_PRIVATE).edit().putString("token", token).apply();
                new AlertDialog.Builder(this).setTitle("Тестовый FCM-токен")
                    .setMessage("Этот токен нужен для теста в Firebase Console. Не публикуй его.\n\n" + token)
                    .setPositiveButton("Скопировать", (dialog, which) -> {
                        ClipboardManager cb = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        cb.setPrimaryClip(ClipData.newPlainText("FCM token", token));
                    })
                    .setNegativeButton("Закрыть", null).show();
            })
            .addOnFailureListener(e -> 
                new AlertDialog.Builder(this).setTitle("Нет токена")
                    .setMessage("Проверь интернет, наличие Google Play Services и настройки Firebase.")
                    .setPositiveButton("ОК", null).show());
    }
    
    private class Bridge {
        @JavascriptInterface 
        public void requestNotifications() { runOnUiThread(() -> MainActivity.this.requestNotifications()); }
        
        @JavascriptInterface 
        public void showToken() { runOnUiThread(() -> MainActivity.this.showToken()); }
        
        @JavascriptInterface 
        public void notificationSettings() { 
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()))); 
        }
        
        @JavascriptInterface 
        public void notifyMessage(String peer, String body, String id) { 
            runOnUiThread(() -> Notifications.show(MainActivity.this, "message", peer, body, peer, id)); 
        }
        
        @JavascriptInterface 
        public void notifyIncoming(String peer, String id) { 
            runOnUiThread(() -> {
                if (!resumed) 
                    Notifications.show(MainActivity.this, "call", "Входящий звонок", peer, peer, id);
            }); 
        }
        
        @JavascriptInterface 
        public void beginCall(String peer) { 
            runOnUiThread(() -> {
                if (!resumed || 
                    ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) 
                    return;
                try {
                    ContextCompat.startForegroundService(MainActivity.this, 
                        new Intent(MainActivity.this, CallService.class).putExtra("peer", peer));
                } catch (RuntimeException ignored) {}
            }); 
        }
        
        @JavascriptInterface 
        public void endCall() { 
            runOnUiThread(() -> stopService(new Intent(MainActivity.this, CallService.class))); 
        }
    }
}
