package com.grofik.dnevnik;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;

public class PushHandlerService extends Service {
    private static final String CHANNEL_PUSH = "diary_push_handler";
    private static final int ONGOING_ID = 9002;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        String action = intent.getAction();
        if ("com.grofik.dnevnik.ACTION_PROCESS_PUSH".equals(action)) {
            processPush(intent);
        }

        Notification ongoing = buildOngoingNotification();
        ServiceCompat.startForeground(this, ONGOING_ID, ongoing, 
            Build.VERSION.SDK_INT >= 30 ? android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC : 0);
        
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
        }, 5000);

        return START_NOT_STICKY;
    }

    private void processPush(Intent intent) {
        String kind = intent.getStringExtra("kind");
        String title = intent.getStringExtra("title");
        String body = intent.getStringExtra("body");
        String peer = intent.getStringExtra("peer");
        String eventId = intent.getStringExtra("eventId");

        if (kind == null) kind = "message";
        if (title == null) title = "Дневник";
        if (body == null) body = "Новое уведомление";

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "DiaryPushWakeLock");
        wakeLock.acquire(10000);

        try {
            showNotification(this, kind, title, body, peer, eventId);
        } finally {
            if (wakeLock.isHeld()) {
                wakeLock.release();
            }
        }
    }

    private void showNotification(Context context, String kind, String title, String body, String peer, String eventId) {
        createChannel(context);

        if (Build.VERSION.SDK_INT >= 33) {
            if (context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 
                    android.content.pm.PackageManager.PERMISSION_GRANTED) {
                return;
            }
        }

        boolean isCall = "call".equals(kind);
        Intent launchIntent = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (peer != null && !peer.isEmpty()) {
            launchIntent.putExtra("peer", peer);
        }

        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                (peer == null ? 0 : peer.hashCode()),
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_PUSH)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(limit(title, 100))
                .setContentText(limit(body, 500))
                .setStyle(new NotificationCompat.BigTextStyle().bigText(limit(body, 500)))
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(isCall ? NotificationCompat.CATEGORY_CALL : NotificationCompat.CATEGORY_MESSAGE)
                .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
                .setOnlyAlertOnce(true);

        if (isCall) {
            builder.setTimeoutAfter(45000)
                    .addAction(0, "Открыть звонок", pendingIntent)
                    .setFullScreenIntent(pendingIntent, true);
        }

        int id = (kind + ":" + (eventId == null ? peer : eventId)).hashCode() & 0x7fffffff;
        if (id == 9001 || id == 9002) id++;

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(id, builder.build());
    }

    private Notification buildOngoingNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_PUSH)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Дневник")
                .setContentText("Обработка уведомлений...")
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .build();
    }

    private void createChannel(Context context) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager.getNotificationChannel(CHANNEL_PUSH) == null) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_PUSH, "Обработчик пушей", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Фоновая обработка push-уведомлений");
            channel.setLockscreenVisibility(NotificationCompat.VISIBILITY_PRIVATE);
            channel.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                    new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build());
            manager.createNotificationChannel(channel);
        }
    }

    private static String limit(String s, int n) {
        if (s == null) return "";
        return s.length() > n ? s.substring(0, n) : s;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

