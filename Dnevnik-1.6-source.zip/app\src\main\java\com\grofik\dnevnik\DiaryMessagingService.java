package com.grofik.dnevnik;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.PowerManager;
import androidx.core.app.NotificationCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;

public class DiaryMessagingService extends FirebaseMessagingService {
    private static final String CHANNEL_MESSAGES = "diary_messages";
    private static final String CHANNEL_CALLS = "diary_incoming_calls";

    @Override
    public void onNewToken(String token) {
        getSharedPreferences("push", MODE_PRIVATE).edit().putString("token", token).apply();
    }

    @Override
    public void onMessageReceived(RemoteMessage m) {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "DiaryPushWakeLock");
        wakeLock.acquire(10000);

        try {
            handleMessage(m);
        } finally {
            if (wakeLock.isHeld()) {
                wakeLock.release();
            }
        }
    }

    private void handleMessage(RemoteMessage m) {
        Map<String, String> d = m.getData();
        String kind = d.getOrDefault("type", "message");
        String peer = d.getOrDefault("peer", "");
        RemoteMessage.Notification n = m.getNotification();
        String title = d.getOrDefault("title", n == null ? "Дневник" : n.getTitle());
        String body = d.getOrDefault("body", n == null ? "Новое уведомление" : n.getBody());
        String eventId = d.getOrDefault("eventId", m.getMessageId());

        if ("call".equals(kind)) {
            try {
                long expires = Long.parseLong(d.getOrDefault("expiresAt", "0"));
                if (expires > 0 && expires < System.currentTimeMillis()) return;
            } catch (NumberFormatException e) {
                return;
            }
        }

        showNotification(this, kind, title, body, peer, eventId);
    }

    private void showNotification(Context context, String kind, String title, String body, String peer, String eventId) {
        createChannels(context);

        if (Build.VERSION.SDK_INT >= 33) {
            if (context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 
                    android.content.pm.PackageManager.PERMISSION_GRANTED) {
                return;
            }
        }

        boolean isCall = "call".equals(kind);
        Intent intent = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (peer != null && !peer.isEmpty()) {
            intent.putExtra("peer", peer);
        }

        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                (peer == null ? 0 : peer.hashCode()),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, isCall ? CHANNEL_CALLS : CHANNEL_MESSAGES)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(limit(title, 100))
                .setContentText(limit(body, 500))
                .setStyle(new NotificationCompat.BigTextStyle().bigText(limit(body, 500)))
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(isCall ? NotificationCompat.CATEGORY_CALL : NotificationCompat.CATEGORY_MESSAGE)
                .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
                .setOnlyAlertOnce(true);

        if (isCall) {
            builder.setTimeoutAfter(45000)
                    .addAction(0, "Открыть звонок", pendingIntent)
                    .setFullScreenIntent(pendingIntent, true);
        }

        int id = (kind + ":" + (eventId == null ? peer : eventId)).hashCode() & 0x7fffffff;
        if (id == 9001) id++;

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(id, builder.build());
    }

    private void createChannels(Context context) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager.getNotificationChannel(CHANNEL_MESSAGES) == null) {
            NotificationChannel messages = new NotificationChannel(CHANNEL_MESSAGES, "Сообщения", NotificationManager.IMPORTANCE_HIGH);
            messages.setDescription("Уведомления чата");
            messages.setLockscreenVisibility(NotificationCompat.VISIBILITY_PRIVATE);
            messages.enableVibration(true);
            messages.setShowBadge(true);
            manager.createNotificationChannel(messages);
        }
        if (manager.getNotificationChannel(CHANNEL_CALLS) == null) {
            NotificationChannel calls = new NotificationChannel(CHANNEL_CALLS, "Входящие звонки", NotificationManager.IMPORTANCE_HIGH);
            calls.setDescription("Уведомления о входящих звонках");
            calls.setLockscreenVisibility(NotificationCompat.VISIBILITY_PRIVATE);
            calls.enableVibration(true);
            calls.setShowBadge(true);
            calls.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),
                    new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build());
            manager.createNotificationChannel(calls);
        }
    }

    private static String limit(String s, int n) {
        if (s == null) return "";
        return s.length() > n ? s.substring(0, n) : s;
    }
}

