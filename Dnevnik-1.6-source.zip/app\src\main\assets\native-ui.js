(() => {
'use strict';
let pendingPeer='';
function unavailable(){window.showToast?.('Только в Android','Эта функция доступна в новой Android-сборке.');}
function invoke(name){if(window.DiaryAndroid?.[name])window.DiaryAndroid[name]();else unavailable();}
function openPeer(peer){if(typeof peer!=='string'||peer.length>100)return;pendingPeer=peer;tryOpen();}
function tryOpen(){if(!pendingPeer||!window.currentUser||!window.myFriends?.[pendingPeer]||!window.openChatRoom)return;const peer=pendingPeer;pendingPeer='';window.switchTab?.('messenger-screen');window.switchMessengerSubTab?.('chats');window.openChatRoom(peer);}
window.DiaryNativeUI={permission:()=>invoke('requestNotifications'),token:()=>invoke('showToken'),settings:()=>invoke('notificationSettings'),openPeer};
document.addEventListener('diary-ready',tryOpen);document.addEventListener('diary-data',tryOpen);
})();
