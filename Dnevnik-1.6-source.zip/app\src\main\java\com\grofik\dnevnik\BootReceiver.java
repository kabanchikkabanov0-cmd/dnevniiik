package com.grofik.dnevnik;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            Intent firebaseIntent = new Intent(context, DiaryMessagingService.class);
            firebaseIntent.setAction("com.google.firebase.MESSAGING_EVENT");
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(firebaseIntent);
            } else {
                context.startService(firebaseIntent);
            }

            Intent pushIntent = new Intent(context, PushHandlerService.class);
            pushIntent.setAction("com.grofik.dnevnik.ACTION_PROCESS_PUSH");
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(pushIntent);
            } else {
                context.startService(pushIntent);
            }
        }
    }
}

